Note: make sure you have nodejs installed with version >= 17.0.1

#Run React Code:

-> goto project directory -> open cmd here -> run command "npm install" to install all dependencies (node modules) -> run command "npm start" to start react server -> visit localhost:3000 to view change
"# itruck" 
"# itruck" 
"# frontend" 
